STUDENT STUDY TASK TRACKER
Author: Bashiru Abdul-Mumin Mandeiya (01250318C)
ATU Virtual Internship - Software Development Individual Mini Project

FILES
- index.html : page structure (form, task list, filter)
- style.css  : layout and colours
- script.js  : add, complete, delete, filter, validation and local storage

HOW TO RUN
Open index.html in any browser. No installation, login or API keys needed.

FEATURES
- Add a task with a title and subject/course
- Blank titles are rejected with an error message
- Tasks shown in a list with a "x of y completed" counter
- Mark complete / change back to incomplete
- Delete a task
- Tasks stay saved after refresh (browser local storage)
- Helpful message when the list is empty
- Extra feature: High / Normal / Low priority and an All / Incomplete / Completed filter

PUBLISHING (GitHub Pages)
Upload the four files to a public GitHub repository, then Settings > Pages >
Deploy from branch > main > / (root). No passwords or secret keys are used.
