// Student Study Task Tracker - tasks are stored in the browser's local storage.
var STORAGE_KEY = "studyTaskTracker.tasks";

var form = document.getElementById("task-form");
var titleInput = document.getElementById("task-title");
var subjectInput = document.getElementById("task-subject");
var priorityInput = document.getElementById("task-priority");
var filterSelect = document.getElementById("task-filter");
var listEl = document.getElementById("task-list");
var countEl = document.getElementById("task-count");
var messageEl = document.getElementById("form-message");

var tasks = loadTasks();

function loadTasks() {
  try {
    var saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(saved) ? saved : [];
  } catch (error) {
    return [];
  }
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    showMessage("Could not save tasks in this browser.", false);
  }
}

function showMessage(text, ok) {
  messageEl.textContent = text;
  messageEl.className = "message" + (ok ? " ok" : "");
}

function addTask(event) {
  event.preventDefault();
  var title = titleInput.value.trim();

  if (title === "") {
    showMessage("Please enter a task title before adding.", false);
    titleInput.focus();
    return;
  }

  tasks.unshift({
    id: Date.now(),
    title: title,
    subject: subjectInput.value.trim(),
    priority: priorityInput.value,
    completed: false
  });
  saveTasks();
  form.reset();
  showMessage("Task added.", true);
  titleInput.focus();
  render();
}

function toggleTask(id) {
  tasks.forEach(function (task) {
    if (task.id === id) task.completed = !task.completed;
  });
  saveTasks();
  render();
}

function deleteTask(id) {
  tasks = tasks.filter(function (task) { return task.id !== id; });
  saveTasks();
  showMessage("Task deleted.", true);
  render();
}

function emptyState(heading, text) {
  var box = document.createElement("div");
  box.className = "empty";
  var strong = document.createElement("strong");
  strong.textContent = heading;
  box.appendChild(strong);
  box.appendChild(document.createTextNode(text));
  return box;
}

function render() {
  var filter = filterSelect.value;
  var completedCount = tasks.filter(function (t) { return t.completed; }).length;
  countEl.textContent = tasks.length === 0
    ? "No tasks yet"
    : completedCount + " of " + tasks.length + " completed";

  var visible = tasks.filter(function (task) {
    if (filter === "incomplete") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  listEl.innerHTML = "";

  if (visible.length === 0) {
    if (tasks.length === 0) {
      listEl.appendChild(emptyState("No tasks yet.", "Add your first study task using the form above."));
    } else if (filter === "incomplete") {
      listEl.appendChild(emptyState("No incomplete tasks.", "All your tasks are done."));
    } else {
      listEl.appendChild(emptyState("No completed tasks yet.", "Tick a task to see it here."));
    }
    return;
  }

  visible.forEach(function (task) {
    var row = document.createElement("article");
    row.className = "task " + task.priority.toLowerCase() + (task.completed ? " completed" : "");

    var box = document.createElement("input");
    box.type = "checkbox";
    box.checked = task.completed;
    box.setAttribute("aria-label", "Mark \u201c" + task.title + "\u201d as " + (task.completed ? "incomplete" : "complete"));
    box.addEventListener("change", function () { toggleTask(task.id); });

    var info = document.createElement("div");
    info.className = "info";
    var name = document.createElement("p");
    name.className = "name";
    name.textContent = task.title;
    var detail = document.createElement("p");
    detail.className = "detail";
    detail.textContent = (task.subject || "No subject") + " \u2022 " + task.priority + " priority";
    info.appendChild(name);
    info.appendChild(detail);

    var del = document.createElement("button");
    del.type = "button";
    del.className = "delete";
    del.textContent = "Delete";
    del.addEventListener("click", function () { deleteTask(task.id); });

    row.appendChild(box);
    row.appendChild(info);
    row.appendChild(del);
    listEl.appendChild(row);
  });
}

form.addEventListener("submit", addTask);
filterSelect.addEventListener("change", render);
render();
